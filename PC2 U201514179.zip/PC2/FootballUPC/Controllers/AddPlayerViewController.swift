//
//  AddPlayerViewController.swift
//  FootballUPC
//
//  Created by Alumnos on 4/11/18.
//  Copyright © 2018 Alumnos. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class AddPlayerViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPosition: UITextField!
    @IBOutlet weak var dpDateOfBirth: UIDatePicker!
    @IBOutlet weak var txtMarketValue: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnSave(_ sender: Any) {
        let objPlayer = Player()
        objPlayer.ID = 0
        objPlayer.Owner = "jorge"
        objPlayer.Name = txtName.text!
        objPlayer.Position = txtPosition.text!
        objPlayer.DateOfBirth = dpDateOfBirth.date
        objPlayer.MarketValue = (Double(txtMarketValue.text!))!
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        
        
        let playerParameters: Parameters = [
            "Owner": objPlayer.Owner,
            "Name": objPlayer.Name,
            "Position": objPlayer.Position,
            "DateOfBirth": formatter.string(from: objPlayer.DateOfBirth),
            "MarketValue": objPlayer.MarketValue,
        ]
        
        Alamofire.request("http://vmdev.nexolink.com:90/footballUPC/api/Player",
                          method: .post,
                          parameters: playerParameters,
                          encoding: JSONEncoding.default)
            .response { response in
                print("Request: \(response.request)")
                print("Response: \(response.response)")
                print("Error: \(response.error)")
                
                if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
                    print("Data: \(utf8Text)")
                }
                
                var message = ""
                var title = ""
                if(response.error == nil){
                    title = "Success"
                    message = "Player saved!"
                }
                else{
                    title = "Error"
                    message = "An error has occurred! Please try again!"
                }
                
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                    
                    if(title == "Success"){
                        self.navigationController?.popViewController(animated: true)
                    }
                }))
                self.present(alert, animated: true, completion: nil)
        }
        txtName.text = ""
        txtPosition.text = ""
        txtMarketValue.text = ""
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
