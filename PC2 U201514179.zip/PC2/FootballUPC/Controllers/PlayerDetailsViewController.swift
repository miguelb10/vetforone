//
//  PlayerDetailsViewController.swift
//  FootballUPC
//
//  Created by Alumnos on 4/11/18.
//  Copyright © 2018 Alumnos. All rights reserved.
//

import UIKit

class PlayerDetailsViewController: UIViewController {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblPosition: UILabel!
    @IBOutlet weak var lblDoB: UILabel!
    @IBOutlet weak var lblMarketValue: UILabel!
    
    
    var objPlayer: Player? = nil

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if(self.objPlayer != nil){
            let df = DateFormatter()
            df.dateFormat = "yyyy-MM-dd"
            self.lblName.text = self.objPlayer?.Name
            self.lblPosition.text = self.objPlayer?.Position
            self.lblDoB.text = df.string(from: (self.objPlayer?.DateOfBirth)!)
            print("Load data")
            self.lblMarketValue.text = String(format: "%f", (self.objPlayer?.MarketValue)!)
        }
        else{
            print("Clear data")
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
