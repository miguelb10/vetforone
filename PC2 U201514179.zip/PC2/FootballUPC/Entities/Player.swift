//
//  Player.swift
//  FootballUPC
//
//  Created by Alumnos on 4/11/18.
//  Copyright © 2018 Alumnos. All rights reserved.
//

import UIKit

class Player: NSObject {
    var ID = 0
    var Owner = ""
    var Name = ""
    var Position = ""
    var DateOfBirth: Date = Date()
    var MarketValue = 0.0
}
