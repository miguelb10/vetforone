//
//  DetailsViewController.swift
//  EF201801
//
//  Created by Miguel Blas on 11/28/18.
//  Copyright © 2018 Miguel Blas. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import CoreData

class DetailsViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtCapital: UITextField!
    
    @IBOutlet weak var txtCant: UITextField!
    var objCountrie : Countrie? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if(self.objCountrie != nil){
            self.txtName.text = self.objCountrie?.name
            self.txtCapital.text = self.objCountrie?.capital
            print("Load data")
        }
        else{
            self.txtName.text = ""
            self.txtCapital.text = ""
            print("Clear data")
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
