//
//  HomeViewController.swift
//  EF201801
//
//  Created by Miguel Blas on 11/28/18.
//  Copyright © 2018 Miguel Blas. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func btnHome(_ sender: Any) {
        self.performSegue(withIdentifier: "home", sender: self)
    }
    
    /*
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
