//
//  Countrie.swift
//  EF201801
//
//  Created by Miguel Blas on 11/28/18.
//  Copyright © 2018 Miguel Blas. All rights reserved.
//

import UIKit

class Countrie: NSObject {
    
    var name : String = ""
    var capital : String = ""
    var region : String = ""

}
